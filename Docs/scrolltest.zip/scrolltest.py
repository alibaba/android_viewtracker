# -*- coding: utf-8 -*-
'''
Created on 2013-8-15

@author: gavinliang
'''

import os, sys, time,threading
sys.path.append(os.path.dirname(__file__))
from optparse import OptionParser
from fpsmonitor import FpsMonitor
from adbdevice import AndroidDevice
class ScrollActions:
    UpScroll, DownScroll, UpAndDownScroll, LeftScroll, RightScroll = ("u", "d", "ud", "l", "r")

def scrollTest(action, count, delaytime):

    if action == ScrollActions.DownScroll:
        for i in range(count):
            monkeydevice.drag((device_half_width, scroll_min_height + 50),(device_half_width, device_height),0.2,10)#开始，结束，持续时间，步骤
            time.sleep(delaytime)
    elif action == ScrollActions.UpScroll:
        for i in range(count):
            monkeydevice.drag((device_half_width, scroll_max_height),(device_half_width, 0),0.2,10)#开始，结束，持续时间，步骤 
            time.sleep(delaytime)
    elif action == ScrollActions.UpAndDownScroll:
        for i in range(count):
            monkeydevice.drag((device_half_width, scroll_max_height),(device_half_width, 0),0.2,10)#开始，结束，持续时间，步骤 
            time.sleep(delaytime)
            monkeydevice.drag((device_half_width, scroll_min_height + 50),(device_half_width, device_height),0.2,10)#开始，结束，持续时间，步骤
            time.sleep(delaytime)
    elif action == ScrollActions.LeftScroll:
        for i in range(count):
            monkeydevice.drag((scroll_max_width, device_half_height),(scroll_min_width, device_half_height),0.2,10)#开始，结束，持续时间，步骤 
            time.sleep(delaytime)
    elif action == ScrollActions.RightScroll:
        for i in range(count):
            monkeydevice.drag((scroll_min_width, device_half_height), (scroll_max_width, device_half_height),0.2,10)#开始，结束，持续时间，步骤 
            time.sleep(delaytime)
            
if __name__ == "__main__":
    usage = '''
      -usage: monkeyrunner scrolltest.py [options]
      -example: monkeyrunner scrolltest.py -a d -p com.tencent.mobileqq
      -options：
      -a --action scrollDirection, [u,d,ud] UpScroll,DownScroll,UpAndDownScroll
           (can set mutiple actions:  -a u -a d, means UpScroll X times,
            then DownScroll X times)
      -c --count scrollTimes, default:20
      -d --serialNumber When multiple phones connected, must specify the 
           device number
      -n --appPackName The packname for the app
      -o --outfile result file, default:fps_result.csv
      -t --delaytime 
    '''
    parser = OptionParser(usage)    
    parser.add_option('-a', '--actions', dest='actions', action="append",default=[])
    parser.add_option('-c', '--count', dest='count', default=10)
    parser.add_option('-d', '--serialNumber', dest='serialNumber')
    parser.add_option('-n', '--appPackName', dest='appPackName')
    parser.add_option('-o', '--outFile', dest="outFileName", default='fps_result.csv')
    parser.add_option('-t', '--delaytime', dest='delaytime', default=1)
    
    (options, args) = parser.parse_args()    
    if not options.appPackName:
        print '\n-n option must be setted'
        print usage
        sys.exit(1)
    if not options.actions:
        print '\n-a option must be setted'
        print usage
        sys.exit(1)    
    print 'Starting ...'
    from com.android.monkeyrunner import MonkeyRunner, MonkeyDevice, MonkeyImage
    if options.serialNumber :
        monkeydevice = MonkeyRunner.waitForConnection(10,options.serialNumber)
    else :
        monkeydevice = MonkeyRunner.waitForConnection()        
    if not monkeydevice:
        print "Can not connect to device, please confirm you phone has connect to PC"
        sys.exit(1)
     
    device_width = int(720)
    device_height = int(1280)
    scroll_min_width = int(device_width * 0.2)
    scroll_max_width = int(device_width * 0.8)
    scroll_min_height = int(device_height * 0.2)
    scroll_max_height = int(device_height * 0.8)
    device_half_width = int(device_width / 2)
    device_half_height = int(device_height / 2)
    
    androiddevice = AndroidDevice(options.serialNumber)
    fpsmonitor = FpsMonitor(androiddevice, options.appPackName, options.outFileName)
    fpsmonitor.start()
    for action in options.actions:
        scrollTest(action, int(options.count), float(options.delaytime))
    fpsmonitor.stop()
