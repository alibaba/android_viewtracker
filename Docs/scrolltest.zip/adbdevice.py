# -*- coding: utf-8 -*-
import time,os,sys
import subprocess
import threading,thread

cur_path = os.path.dirname(os.path.abspath(__file__))
adb_path = os.path.join(cur_path, 'tools', 'adb.exe ')

class AdbCommands():
    def __init__(self, adbArgv=None):
        """
        @param adbArgv:adb
        @author: brantbzhang
        @sample: 
        adbd = AdbCommands("-s 015F3EE203017013")
        """
        self.adb=adb_path
        if adbArgv:
            self.adb = self.adb + adbArgv + " "
        
    def timer(self,process,timeout):
        num=0
        while process.poll()==None and num<timeout*10:
            num+=1
            time.sleep(0.1)
        if process.poll()==None:
            os.system("taskkill /T /F /PID %d"%process.pid)
            print "%d process timeout ,be killed！"%process.pid
        thread.exit_thread()

    def runShellCmd(self,Cmd,TimeOut=3):
        return self.runCmd("shell \"%s\" "%Cmd, TimeOut)
    
    def runRootShellCmd(self,Cmd,TimeOut=3):
        res=self.runShellCmd("""su -c '%s'"""%Cmd, TimeOut)
        if res:
            for res_tiem in res:
                if "No such file or directory" in res_tiem:
                    res=self.runShellCmd("""su -c %s"""%Cmd, TimeOut)
                    break
        if 'Permission denied' in res :
            print 'permission denied!!!'
            print 'Please confirm you phone have rooted'
            sys.exit(1)
        return res

    def isRootType(self):
        res = self.RunShellCommand("id", 20, False)
        if "root" in res[0]:
            return True
        return False

    def getSystemVersion(self):
        return self.runCmd("shell getprop ro.build.version.release", 10)[0]
    
    def findTagIndex(self, findtag, line):
        data = line.split()
        index = 0

        for tag in data:
            if findtag.lower() in tag.lower():
                return index
            index = index + 1
    
    def extractPid(self, process_name):
        """Extracts Process Ids for a given process name from Android Shell.
        
        Args:
          process_name: name of the process on the device.
        
        Returns:
          List of all the process ids (as strings) that match the given name.
        """
        pids = []
        res = self.runCmd('shell ps')
        index = self.findTagIndex("pid", res[0])
        for line in res:
            data = line.split()
            try:
                if process_name in data[-1]:  # name is in the last column
                    pids.append(data[index])  # PID is in the second column
            except IndexError:
                pass
        return pids
    
    def KillAll(self, processname):
        """Android version of killall, connected via adb.
        
        Args:
          process: name of the process to kill off
        
        Returns:
          the number of processess killed
        """
        if not self.isRootType():
            print "fail:please install https://tc-svn.tencent.com/pub/pub_MobileTestTools_rep/MobileTestTools_proj/trunk/performance/DroidShell/adbd-Insecure-v1.1.apk to gain the root adb"
            return 0
        pids = self.extractPid(processname)
        if pids:
            self.runCmdSync('shell kill ' + ' '.join(pids))
        return len(pids)
    
    def runCmdOnResult(self, Cmd, waitForResult):
        process =  subprocess.Popen(self.adb+Cmd, stdout=subprocess.PIPE)
        for i in range(30):
            result = process.stdout.readline()
            print result
            if waitForResult in result:
                break
            time.sleep(0.2)
    
    def runCmdReturnSubprocess(self, cmd):
        cmdlet = self.adb+cmd
        print "run cmdlet",cmdlet
        process = subprocess.Popen(cmdlet,stdin=subprocess.PIPE,stdout=subprocess.PIPE,shell=True)
        return process
    
    def runCmdSync(self, cmd):
        cmdlet = self.adb+cmd
        print "run cmdlet",cmdlet
        stds = os.popen(cmdlet)
        print stds.readlines()
        for line in stds.readlines():
            print line
        
    def runCmdPopenSync(self, cmd):
        cmdlet = self.adb+cmd
        print "run cmdlet:" + cmdlet
        std = os.popen(cmdlet)
        res=std.read()
        res=res.replace("\r\n","\n").splitlines()
        return res
    
    def runCmdOnce(self,Cmd,TimeOut=3):
        process=subprocess.Popen(self.adb+Cmd,stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.PIPE,shell=True)
        thread.start_new_thread(self.timer,(process,TimeOut))    
        res=process.stdout.read()
        process.wait()
        if process.poll() != 0:
            error=process.stderr.read()
            print error
            if "killing" in (res or error):
                print 
                sys.exit(1)
            if ("device not found" or "offline") in (res or error):
                print 'Please confirm you phone have connect to PC!!!'
                sys.exit(1)
            if "Android Debug Bridge version" in (res or error):
                print 'Adb cmd error!!!! Please check you adb cmd!!!'
                sys.exit(1)
            if "more than one" in (res or error):
                print 'More then one device, Please set -d option '
                sys.exit(1)
            sys.exit(1)
        res=res.replace("\r\n","\n").splitlines()
        return res
        
    def runCmd(self,Cmd,TimeOut=3,Retry=3):
        while Retry>=0:
            res=self.runCmdOnce(Cmd, TimeOut)
            if res!=None:
                break
            Retry-=1
        return res
            
    def stop_package(self,packagename):
        self.runCmd("shell am force-stop %s"%packagename)
    
    def clear_package(self,packagename):
        """
        @summary: 
        """
        self.runCmd("shell pm clear %s"%packagename)

        
class AndroidDevice(AdbCommands):
    
    def __init__(self,serialNumber = None):
        if serialNumber:
            AdbCommands.__init__(self,"-s %s"%self.serialNumber)
        else:
            AdbCommands.__init__(self)

    
    