# -*- coding: utf-8 -*-
'''
Created on 2013-8-13

@author: gavinliang
'''
import csv,traceback,sys,os,threading,time,optparse
from surface_stats_collector import SurfaceStatsCollector
from adbdevice import AndroidDevice

class FpsMonitor(object):

    def __init__(self, device, packagename, resultfilepath, frequency=1):
        self.device = device
        self.packagename = packagename
        self.resultfilepath = resultfilepath
        self.frequency = frequency #取样频率
        self.activityname = None        
        self.running = False
        self.results = {}
        
        if ':' not in resultfilepath :
            resultfilepath  = os.path.dirname(os.path.abspath(__file__)) + '\\'+resultfilepath
        
        try :
            self.csv_file = open(resultfilepath, 'wb')
            self.writer = csv.writer(self.csv_file)
        except :
            print(traceback.format_exc(),'Can not open file:%s, Please check this file is opened? close it! '%self.resultfilepath)
            sys.exit()
        if self._isNeedActvityName() :
            self._getActvityFromPackageName()            
        self.fpscollector = SurfaceStatsCollector(self.device,self.activityname,self.frequency)
            
    def _isNeedActvityName(self):
        '''判断当前系统是否支持 SurfaceFlinger latency，若支持，则需要指定Activity名称
                                当支持 SurfaceFlinger latency时，以下命令返回空
        '''
        results = self.device.runRootShellCmd('dumpsys SurfaceFlinger --latency-clear SurfaceView')
        return not len(results)
            
    def _getActvityFromPackageName(self):
        results = self.device.runRootShellCmd('dumpsys SurfaceFlinger --list')
        for line in results :
            if self.packagename in line :
                self.activityname = line
                return self.activityname
        
    def start(self):
        self.running = True
        self._monitorthread= threading.Thread(target=self.monitorThread)
        self._monitorthread.setDaemon(True)
        self._monitorthread.start()
        print('FPS monitor has start!')
        
    def stop(self):
        self.running = False
        self._monitorthread.join(5)
        if self._monitorthread.isAlive() :
            print('FPS monitor thread stop failed')
        self.csv_file.flush()
        self.csv_file.close()
        print('FPS monitor has stop!')
    
    def monitorThread(self):
        row = []
        self.fpscollector.Start()
        ret = self.fpscollector.GetSampleResults()
        for item in ret:
            row.append(item.name)
            self.results[item.name] = []
        self.writer.writerow(row)
        row = []
        while self.running:
            time.sleep(self.frequency)
            ret = self.fpscollector.GetSampleResults()
            if not ret:
                continue
            for item in ret :
                item.print_str()
                row.append(item.value)
                self.results[item.name].append(item.value)
            self.writer.writerow(row)
            row = []
        self.fpscollector.Stop()
        
    
    def getResult(self):
        return self.results

if __name__ == '__main__':
    usage = u"""
      -usage：python fpsmonitor.py [option]
      -example: python fpsmonitor.py -p com.tencent.mobileqq
      -option：
      -d --serialNumber When multiple phones connected, must specify 
           the device number
      -n --appPackName 
      -o --outfile
    """
    parser = optparse.OptionParser(usage)
    parser.add_option('-d', '--serialNumber', dest='serialNumber')
    parser.add_option('-n', '--appPackName', dest='appPackName')
    parser.add_option('-o', '--outFile', dest="outFileName", default='fps_result.csv')
    (options, args) = parser.parse_args()
    
    if not options.appPackName:
        print(u'\n -n option must be setted')
        parser.print_help()
        exit(0)
    device = AndroidDevice(options.serialNumber)
    monitor = FpsMonitor(device, options.appPackName,options.outFileName)
    monitor.start()
    while True:
        try:
            time.sleep(1)
        except KeyboardInterrupt, e:
            break
    monitor.stop()